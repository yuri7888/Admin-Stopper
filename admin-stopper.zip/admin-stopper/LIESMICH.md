# Admin-Stopper

Dieses Programm sorgt dafür, dass **keine CMD- oder PowerShell-Konsole mit
Administrator-Rechten offen bleibt**: Sobald jemand eine Konsole MIT Admin-Rechten
öffnet, schließt der Admin-Stopper sie automatisch und öffnet **dieselbe Konsole
ohne Admin-Rechte neu** (gleicher Befehl, gleicher Arbeitsordner).

Der Wächter selbst startet **automatisch mit Windows** (eingetragen in der
Windows-Aufgabenplanung, Taskname `AdminStopperWachter`).

---

## Einrichtung (einmalig, ca. 1 Minute)

1. **`AdminStopper.exe` doppelklicken.**
   → Es erscheint das Fenster „Admin-Stopper (Verwaltung)“.
2. Auf **„Schutz aktivieren (Autostart einrichten)“** klicken und bestätigen.
   → Es erscheint **einmal** ein Administrator-Fenster (UAC) – bitte mit **„Ja“**
   bestätigen. Das ist nötig, weil der Wächter Admin-Konsolen schließen darf und
   deshalb selbst mit Admin-Rechten läuft.
3. Fertig. Wenn im Fenster jetzt steht:
   - „Autostart mit Windows: ✔ eingerichtet“ und
   - „Wächter läuft gerade: ✔ ja (Schutz aktiv)“
   … ist alles eingerichtet. Ab jetzt startet der Schutz automatisch bei jeder
   Windows-Anmeldung (Fenster „Admin-Stopper (Wächter)“).

> **Wichtig:** Das Fenster „Admin-Stopper (Wächter)“ ist der Schutz selbst.
> Es darf geschlossen werden (dann fragt es nach) – der Schutz ist danach aber
> aus, bis zur nächsten Anmeldung oder bis zum erneuten Start über die Verwaltung.

## Fenster ausblenden (Infobereich / Pfeil-Symbol der Taskleiste)

- Im Wächter-Fenster auf **„In den Infobereich ausblenden (Taskleiste ^)“**
  klicken → das Fenster verschwindet aus der Taskleiste. Unten rechts im
  Pfeil-Menü (^ → „Ausgeblendete Symbole einblenden“) bleibt ein
  **Schild-Symbol** übrig. **Ein Klick auf das Schild** holt das Fenster zurück.
- Mit dem Häkchen **„Beim Start ausgeblendet“** startet der Wächter bei jeder
  Anmeldung direkt ausgeblendet (nur Schild-Symbol, kein Fenster).

## Testen (so prüfst du, dass es funktioniert)

1. Doppelklick auf **`PRUEFEN.bat`** (oder im Verwaltungsfenster auf
   „Testen: Admin-Fenster öffnen“ klicken) und im UAC-Fenster „Ja“ bestätigen.
2. **Erwartung:** Das CMD-Fenster mit Admin-Rechten verschwindet nach ca. 1–2
   Sekunden von selbst. Ein neues Fenster öffnet sich; darin meldet `net session`
   **„Zugriff verweigert“** – das neue Fenster ist also ohne Admin-Rechte.
3. Im Wächter-Fenster steigt der Zähler „Admin-Konsolen automatisch neu gestartet“
   und es ertönt ein kurzer Signalton.

## Schutz vorübergehend aussetzen

Im Wächter-Fenster auf **„Pausieren“** klicken → es wird nichts überwacht.
Mit **„Fortsetzen“** geht es weiter. (Nützlich, wenn du kurzzeitig bewusst eine
Admin-Konsole brauchst.)

## Schutz ganz entfernen

1. `AdminStopper.exe` doppelklicken (Verwaltungsfenster).
2. Auf **„Schutz deaktivieren (Autostart entfernen)“** klicken und im UAC-Fenster „Ja“ bestätigen.
   → Autostart-Eintrag wird gelöscht und der laufende Wächter gestoppt.

## Gut zu wissen

- **Das Fenster der neu gestarteten Konsole** trägt den Titel „Admin-Stopper – ohne
  Administrator neu gestartet". Das ist normal und zeigt: Hier wurde gerade eine
  Admin-Konsole automatisch umgeleitet.
- **Installationsroutinen:** Manche Installationsprogramme rufen im Hintergrund
  eine CMD mit Admin-Rechten auf. Solange der Wächter läuft, wird auch diese
  geschlossen und ohne Admin neu gestartet – bei Problemen mit einer Installation
  den Wächter vorher kurz **pausieren**.
- **Fremde Benutzerkonten und Windows-Systemprozesse (SYSTEM) werden nie
  angetastet** – es betrifft nur Konsolen deines eigenen Benutzerkontos
  (cmd.exe, powershell.exe, pwsh.exe).
- Wurde eine Admin-Konsole **als anderer Benutzer** gestartet, bleibt sie unberührt.
- **Protokoll:** Im Verwaltungsfenster „Protokoll anzeigen“ klicken, oder Datei
  `%LOCALAPPDATA%\AdminStopper\waechter.log` öffnen. Dort steht jede Umleitung
  mit Uhrzeit.
- Falls Windows beim ersten Start eine Sicherheitswarnung (SmartScreen) zeigt:
  „Weitere Informationen“ → „Trotzdem ausführen“.
- Technischer Hintergrund: Zum Starten ohne Admin-Rechte erzeugt der Wächter ein
  nicht-erhöhtes Token des angemeldeten Benutzers und startet die Konsole damit
  neu. Funktioniert auch, wenn der Explorer selbst mit Admin-Rechten läuft
  (wie auf diesem PC der Fall).

## Dateien in diesem Ordner

| Datei | Zweck |
|---|---|
| `AdminStopper.exe` | Das Programm (Verwaltung per Doppelklick, Wächter über Autostart) |
| `PRUEFEN.bat` | Test: öffnet bewusst eine Admin-Konsole zur Kontrolle |
| `LIESMICH.md` | Diese Anleitung |
| `admin_stopper.py` | Quellcode (falls später etwas geändert werden soll) |
