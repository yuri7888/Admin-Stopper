@echo off
echo ============================================================
echo  Admin-Stopper  -  Test
echo ============================================================
echo.
echo Es oeffnet sich jetzt EINMAL ein CMD-Fenster MIT Administrator-
echo rechten. Bitte im UAC-Fenster mit "Ja" bestaetigen.
echo.
echo ERWARTUNG:
echo  1. Das Admin-Fenster verschwindet nach ca. 1-2 Sekunden selbst.
echo  2. Ein NEUES Fenster oeffnet sich automatisch.
echo  3. In dem neuen Fenster meldet "net session": Zugriff verweigert.
echo     Das bedeutet: Das neue Fenster ist OHNE Admin-Rechte. Alles richtig!
echo.
echo Der Waechter muss dafuer laufen (gruener Status im Verwaltungs-
echo fenster von AdminStopper.exe).
echo.
pause
powershell -NoProfile -Command "Start-Process cmd -ArgumentList '/k title Admin-Test && net session' -Verb RunAs"
echo.
echo Test-Fenster wurde gestartet. Bitte im neuen Fenster nachsehen.
echo.
pause
