# -*- coding: utf-8 -*-
"""
Admin-Stopper
=============

Überwacht CMD- und PowerShell-Konsolen des aktuellen Benutzers.
Wird eine Konsole MIT Administrator-Rechten geöffnet, schließt der
Admin-Stopper sie automatisch und startet dieselbe Konsole ohne
Administrator-Rechte neu.

Modi (Kommandozeile):
    (kein Argument)  -> Verwaltungsfenster (ohne Admin-Rechte nutzbar)
    --watch          -> Wächter im Hintergrund (startet über die
                        Windows-Aufgabenplanung automatisch mit Windows)
    --autotest       -> interner Selbsttest, schreibt autotest.json
"""

import ctypes
from ctypes import (WINFUNCTYPE, POINTER, byref, c_int, c_long, c_uint,
                    c_ulong, c_ushort, c_void_p, c_wchar_p, c_size_t,
                    Structure, Union)
import ctypes.wintypes as wt
import json
import os
import queue
import subprocess
import sys
import threading
import time

import tkinter as tk
from tkinter import messagebox, scrolledtext
import winsound

VERSION = "1.0.0"
APP_NAME = "AdminStopper"
TASK_NAME = "AdminStopperWachter"
MUTEX_NAME = "Local\\AdminStopperWaechter"
MARKER = "NOADMIN_SKIP"
WATCH_NAMES = {"cmd.exe", "powershell.exe", "pwsh.exe"}
POLL_SEKUNDEN = 1.0
CREATE_NO_WINDOW = 0x08000000
FENSTER_TITEL = "Admin-Stopper"

DATEN_ORDNER = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), APP_NAME)
LOG_PFAD = os.path.join(DATEN_ORDNER, "waechter.log")
PID_PFAD = os.path.join(DATEN_ORDNER, "wacht_pid.txt")
ZAEHLER_PFAD = os.path.join(DATEN_ORDNER, "zaehler.txt")
AUTOTEST_PFAD = os.path.join(DATEN_ORDNER, "autotest.json")
HELFER_PFAD = os.path.join(DATEN_ORDNER, "helper_NOADMIN_SKIP.ps1")

# --------------------------------------------------------------------------
# Windows-Konstanten
# --------------------------------------------------------------------------
PROCESS_TERMINATE = 0x0001
PROCESS_VM_READ = 0x0010
PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
SYNCHRONIZE = 0x00100000
TH32CS_SNAPPROCESS = 0x2
TOKEN_QUERY = 0x8
TOKEN_USER = 1
TOKEN_ELEVATION = 20
SW_SHOWNORMAL = 1
VT_EMPTY = 0
VT_I4 = 3
VT_BSTR = 8
DISPATCH_METHOD = 2
DISPATCH_PROPERTYGET = 4
LOCALE_USER_DEFAULT = 0x0400
SEE_MASK_NOCLOSEPROCESS = 0x00000040
SEE_MASK_NOASYNC = 0x00000100
ERROR_ALREADY_EXISTS = 183

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
user32 = ctypes.WinDLL("user32", use_last_error=True)
advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
shell32 = ctypes.WinDLL("shell32", use_last_error=True)
ole32 = ctypes.WinDLL("ole32")
oleaut32 = ctypes.WinDLL("oleaut32")
ntdll = ctypes.WinDLL("ntdll")

_LOG_SPERR = threading.Lock()


def _log(text):
    """Schreibt eine Zeile in das Protokoll (LOCALAPPDATA/AdminStopper/waechter.log)."""
    zeile = time.strftime("[%Y-%m-%d %H:%M:%S] ") + text + "\n"
    try:
        with _LOG_SPERR:
            try:
                if os.path.getsize(LOG_PFAD) > 100_000:
                    with open(LOG_PFAD, "rb") as f:
                        f.seek(-30_000, 2)
                        rest = f.read()
                    with open(LOG_PFAD, "wb") as f:
                        f.write(rest)
            except OSError:
                pass
            with open(LOG_PFAD, "a", encoding="utf-8") as f:
                f.write(zeile)
    except OSError:
        pass


# --------------------------------------------------------------------------
# Prozesse, Token, Befehlszeilen
# --------------------------------------------------------------------------
class SID_AND_ATTRIBUTES(Structure):
    _fields_ = [("Sid", c_void_p), ("Attributes", wt.DWORD)]


class PROCESSENTRY32W(Structure):
    _fields_ = [("dwSize", wt.DWORD),
                ("cntUsage", wt.DWORD),
                ("th32ProcessID", wt.DWORD),
                ("th32DefaultHeapID", c_size_t),
                ("th32ModuleID", wt.DWORD),
                ("cntThreads", wt.DWORD),
                ("th32ParentProcessID", wt.DWORD),
                ("pcPriClassBase", c_long),
                ("dwFlags", wt.DWORD),
                ("szExeFile", wt.WCHAR * 260)]

kernel32.CreateToolhelp32Snapshot.argtypes = [wt.DWORD, wt.DWORD]
kernel32.CreateToolhelp32Snapshot.restype = wt.HANDLE
kernel32.Process32FirstW.argtypes = [wt.HANDLE, POINTER(PROCESSENTRY32W)]
kernel32.Process32NextW.argtypes = [wt.HANDLE, POINTER(PROCESSENTRY32W)]
kernel32.OpenProcess.argtypes = [wt.DWORD, wt.BOOL, wt.DWORD]
kernel32.OpenProcess.restype = wt.HANDLE
kernel32.TerminateProcess.argtypes = [wt.HANDLE, wt.UINT]
kernel32.WaitForSingleObject.argtypes = [wt.HANDLE, wt.DWORD]
kernel32.QueryFullProcessImageNameW.argtypes = [wt.HANDLE, wt.DWORD, wt.LPWSTR, POINTER(wt.DWORD)]
advapi32.OpenProcessToken.argtypes = [wt.HANDLE, wt.DWORD, POINTER(wt.HANDLE)]
advapi32.GetTokenInformation.argtypes = [wt.HANDLE, c_int, c_void_p, wt.DWORD, POINTER(wt.DWORD)]
advapi32.ConvertSidToStringSidW.argtypes = [c_void_p, POINTER(wt.LPWSTR)]
kernel32.LocalFree.argtypes = [c_void_p]
ntdll.NtQueryInformationProcess.argtypes = [wt.HANDLE, c_int, c_void_p, c_ulong, POINTER(c_ulong)]
kernel32.ReadProcessMemory.argtypes = [wt.HANDLE, c_void_p, c_void_p, c_size_t, POINTER(c_size_t)]


def prozesse_auflisten():
    """Listet alle Prozesse auf: [(pid, name, eltern_pid), ...]."""
    snapshot = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if not snapshot or snapshot == wt.HANDLE(-1):
        return []
    ergebnis = []
    e = PROCESSENTRY32W()
    e.dwSize = ctypes.sizeof(PROCESSENTRY32W)
    ok = kernel32.Process32FirstW(snapshot, byref(e))
    while ok:
        ergebnis.append((e.th32ProcessID, e.szExeFile, e.th32ParentProcessID))
        ok = kernel32.Process32NextW(snapshot, byref(e))
    kernel32.CloseHandle(snapshot)
    return ergebnis


def _token_sid_als_text(token):
    groesse = wt.DWORD(0)
    advapi32.GetTokenInformation(token, TOKEN_USER, None, 0, byref(groesse))
    if not groesse.value:
        return None
    puffer = ctypes.create_string_buffer(groesse.value)
    if not advapi32.GetTokenInformation(token, TOKEN_USER, puffer, groesse.value, byref(groesse)):
        return None
    saa = ctypes.cast(puffer, POINTER(SID_AND_ATTRIBUTES)).contents
    sid_text = wt.LPWSTR()
    if not advapi32.ConvertSidToStringSidW(saa.Sid, byref(sid_text)):
        return None
    wert = sid_text.value
    kernel32.LocalFree(sid_text)
    return wert


def ist_admin():
    """True, wenn dieser Prozess selbst mit erhöhten Rechten läuft."""
    token = wt.HANDLE()
    if not advapi32.OpenProcessToken(wt.HANDLE(kernel32.GetCurrentProcess()), TOKEN_QUERY | TOKEN_DUPLICATE, byref(token)):
        return False
    try:
        elev = wt.DWORD(0)
        zurueck = wt.DWORD(0)
        if not advapi32.GetTokenInformation(token, TOKEN_ELEVATION, byref(elev),
                                            ctypes.sizeof(elev), byref(zurueck)):
            return False
        return bool(elev.value)
    finally:
        kernel32.CloseHandle(token)


def eigene_benutzer_sid():
    token = wt.HANDLE()
    if not advapi32.OpenProcessToken(wt.HANDLE(kernel32.GetCurrentProcess()), TOKEN_QUERY | TOKEN_DUPLICATE, byref(token)):
        return None
    try:
        return _token_sid_als_text(token)
    finally:
        kernel32.CloseHandle(token)


def token_daten(pid):
    """(erhoeht?, benutzer_sid) eines fremden Prozesses – geht auch aus
    nicht-erhöhtem Kontext (PROCESS_QUERY_LIMITED_INFORMATION)."""
    h = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not h:
        return None
    try:
        token = wt.HANDLE()
        if not advapi32.OpenProcessToken(h, TOKEN_QUERY | TOKEN_DUPLICATE, byref(token)):
            return None
        try:
            sid = _token_sid_als_text(token)
            if sid is None:
                return None
            return (_token_ist_erhoeht(token), sid)
        finally:
            kernel32.CloseHandle(token)
    finally:
        kernel32.CloseHandle(h)


def lese_prozess_strings(pid):
    """Liest (image_pfad, befehlszeile, arbeitsordner) über PEB/ReadProcessMemory."""
    h = kernel32.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, False, pid)
    if not h:
        return (None, None, None)
    try:
        class PBI(Structure):
            _fields_ = [("ExitStatus", c_void_p),
                        ("PebBaseAddress", c_void_p),
                        ("AffinityMask", c_void_p),
                        ("BasePriority", c_void_p),
                        ("UniqueProcessId", c_void_p),
                        ("InheritedFromUniqueProcessId", c_void_p)]
        pbi = PBI()
        rueck = c_ulong(0)
        status = ntdll.NtQueryInformationProcess(h, 0, byref(pbi), ctypes.sizeof(pbi), byref(rueck))
        if status != 0 or not pbi.PebBaseAddress:
            return (None, None, None)

        def lesen(adresse, groesse):
            puffer = ctypes.create_string_buffer(groesse)
            gelesen = c_size_t(0)
            if not kernel32.ReadProcessMemory(h, c_void_p(adresse), puffer, groesse, byref(gelesen)):
                return None
            return puffer.raw[:gelesen.value]

        peb = lesen(pbi.PebBaseAddress, 0x28)
        if not peb:
            return (None, None, None)
        parameter = int.from_bytes(peb[0x20:0x28], "little")
        if not parameter:
            return (None, None, None)
        daten = lesen(parameter, 0x80)
        if not daten:
            return (None, None, None)

        def lese_uni_string(offset):
            laenge = int.from_bytes(daten[offset:offset + 2], "little")
            zeiger = int.from_bytes(daten[offset + 8:offset + 16], "little")
            if laenge == 0 or not zeiger:
                return ""
            inhalt = lesen(zeiger, laenge)
            return inhalt.decode("utf-16-le", "replace") if inhalt else ""

        # x64-Offsets in RTL_USER_PROCESS_PARAMETERS:
        #   0x38 CurrentDirectory.DosPath, 0x60 ImagePathName, 0x70 CommandLine
        return (lese_uni_string(0x60), lese_uni_string(0x70), lese_uni_string(0x38))
    finally:
        kernel32.CloseHandle(h)


def extrahiere_argumente(befehlszeile):
    """Entfernt den Programmteil am Anfang der Befehlszeile, Rest bleibt original."""
    z = befehlszeile.strip()
    if z.startswith('"'):
        i = z.find('"', 1)
        if i == -1:
            return ""
        return z[i + 1:].strip()
    i = z.find(" ")
    return "" if i == -1 else z[i + 1:].strip()


# --------------------------------------------------------------------------
# COM: Programm über die laufende Explorer-Instanz starten (= ohne Admin)
# --------------------------------------------------------------------------
class GUID(Structure):
    _fields_ = [("Data1", c_ulong), ("Data2", c_ushort), ("Data3", c_ushort),
                ("Data4", ctypes.c_ubyte * 8)]

IID_NULL = GUID()


class EXCEPINFO(Structure):
    _fields_ = [("wCode", wt.WORD), ("wReserved", wt.WORD),
                ("bstrSource", c_void_p), ("bstrDescription", c_void_p),
                ("bstrHelpFile", c_void_p), ("dwHelpContext", wt.DWORD),
                ("pvReserved", c_void_p), ("pfnDeferredFillIn", c_void_p),
                ("scode", ctypes.HRESULT)]


class _VariantUnion(Union):
    _fields_ = [("lVal", c_long), ("bstrVal", c_void_p)]


class VARIANT(Structure):
    _anonymous_ = ("u",)
    _fields_ = [("vt", c_ushort), ("wReserved1", wt.WORD),
                ("wReserved2", wt.WORD), ("wReserved3", wt.WORD),
                ("u", _VariantUnion)]


class DISPPARAMS(Structure):
    _fields_ = [("rgvarg", POINTER(VARIANT)),
                ("rgdispidNamedArgs", POINTER(c_long)),
                ("cArgs", c_uint), ("cNamedArgs", c_uint)]


_PROC_QI = WINFUNCTYPE(ctypes.HRESULT, c_void_p, POINTER(GUID), POINTER(c_void_p))
_PROC_REF = WINFUNCTYPE(c_ulong, c_void_p)
_PROC_GTIC = WINFUNCTYPE(ctypes.HRESULT, c_void_p, POINTER(c_uint))
_PROC_GTI = WINFUNCTYPE(ctypes.HRESULT, c_void_p, c_uint, c_ulong, POINTER(c_void_p))
_PROC_GIDS = WINFUNCTYPE(ctypes.HRESULT, c_void_p, POINTER(GUID), POINTER(c_wchar_p),
                         c_uint, c_ulong, POINTER(c_long))
_PROC_INVOKE = WINFUNCTYPE(ctypes.HRESULT, c_void_p, c_long, POINTER(GUID), c_ulong,
                           c_ushort, POINTER(DISPPARAMS), POINTER(VARIANT),
                           POINTER(EXCEPINFO), POINTER(c_uint))


class IDispatchVtbl(Structure):
    _fields_ = [("QueryInterface", _PROC_QI), ("AddRef", _PROC_REF), ("Release", _PROC_REF),
                ("GetTypeInfoCount", _PROC_GTIC), ("GetTypeInfo", _PROC_GTI),
                ("GetIDsOfNames", _PROC_GIDS), ("Invoke", _PROC_INVOKE)]


ole32.CLSIDFromProgID.argtypes = [c_wchar_p, POINTER(GUID)]
oleaut32.GetActiveObject.argtypes = [POINTER(GUID), c_void_p, POINTER(c_void_p)]
oleaut32.SysAllocString.argtypes = [c_wchar_p]
oleaut32.SysAllocString.restype = c_void_p
oleaut32.SysFreeString.argtypes = [c_void_p]
oleaut32.VariantClear.argtypes = [POINTER(VARIANT)]
ole32.CoInitialize.argtypes = [c_void_p]


def _com_vtbl(disp_zeiger):
    vtbl_zeiger = ctypes.cast(disp_zeiger, POINTER(c_void_p)).contents.value
    return ctypes.cast(vtbl_zeiger, POINTER(IDispatchVtbl)).contents


def _var_leer():
    v = VARIANT()
    v.vt = VT_EMPTY
    return v


def _var_zahl(wert):
    v = VARIANT()
    v.vt = VT_I4
    v.lVal = wert
    return v


def _var_text(text):
    v = VARIANT()
    v.vt = VT_BSTR
    v.bstrVal = oleaut32.SysAllocString(text)
    return v


def _com_methode_rufen(disp_zeiger, name, varianten):
    vtbl = _com_vtbl(disp_zeiger)
    dispids = (c_long * 1)()
    name_zeiger = c_wchar_p(name)
    hr = vtbl.GetIDsOfNames(disp_zeiger, byref(IID_NULL), byref(name_zeiger), 1,
                            LOCALE_USER_DEFAULT, dispids)
    if hr != 0:
        raise OSError("GetIDsOfNames fehlgeschlagen (HRESULT 0x%08X)" % (hr & 0xFFFFFFFF))
    # DISPPARAMS erwartet die Argumente in UMGEKEHRTER Reihenfolge
    arg_feld = (VARIANT * len(varianten))(*list(reversed(varianten)))
    dp = DISPPARAMS()
    dp.rgvarg = ctypes.cast(arg_feld, POINTER(VARIANT))
    dp.cArgs = len(varianten)
    dp.cNamedArgs = 0
    ergebnis = VARIANT()
    hr = vtbl.Invoke(disp_zeiger, dispids[0], byref(IID_NULL), LOCALE_USER_DEFAULT,
                     DISPATCH_METHOD | DISPATCH_PROPERTYGET, byref(dp),
                     byref(ergebnis), None, None)
    oleaut32.VariantClear(byref(ergebnis))
    for v in varianten:
        if v.vt == VT_BSTR and v.bstrVal:
            oleaut32.SysFreeString(v.bstrVal)
    if hr != 0:
        raise OSError("Invoke fehlgeschlagen (HRESULT 0x%08X)" % (hr & 0xFFFFFFFF))


# --------------------------------------------------------------------------
# Start ohne Admin: mit dem Token des Explorer-Prozesses (oder über COM)
# --------------------------------------------------------------------------
CREATE_UNICODE_ENVIRONMENT = 0x400
TOKEN_DUPLICATE = 0x0002
TOKEN_QUERY_RIGHTS = 0x0008
TOKEN_ADJUST_PRIVILEGES = 0x0020
MAXIMUM_ALLOWED = 0x02000000
SE_PRIVILEGE_ENABLED = 0x2
ERROR_NOT_ALL_ASSIGNED = 1300
SECURITY_IMPERSONATION = 2
TOKEN_PRIMARY = 1


class STARTUPINFOW(Structure):
    _fields_ = [("cb", wt.DWORD), ("lpReserved", wt.LPWSTR), ("lpDesktop", wt.LPWSTR),
                ("lpTitle", wt.LPWSTR), ("dwX", wt.DWORD), ("dwY", wt.DWORD),
                ("dwXCountChars", wt.DWORD), ("dwYCountChars", wt.DWORD),
                ("dwFillAttribute", wt.DWORD), ("dwFlags", wt.DWORD),
                ("wShowWindow", wt.WORD), ("cbReserved2", wt.WORD),
                ("lpReserved2", c_void_p), ("hStdInput", wt.HANDLE),
                ("hStdOutput", wt.HANDLE), ("hStdError", wt.HANDLE)]


class PROCESS_INFORMATION(Structure):
    _fields_ = [("hProcess", wt.HANDLE), ("hThread", wt.HANDLE),
                ("dwProcessId", wt.DWORD), ("dwThreadId", wt.DWORD)]


class _LUID(Structure):
    _fields_ = [("LowPart", wt.DWORD), ("HighPart", c_long)]


class _TOKEN_PRIVILEGES(Structure):
    _fields_ = [("PrivilegienAnzahl", wt.DWORD), ("Luid", _LUID), ("Attributes", wt.DWORD)]


advapi32.LookupPrivilegeValueW.argtypes = [wt.LPWSTR, wt.LPWSTR, POINTER(_LUID)]
advapi32.AdjustTokenPrivileges.argtypes = [wt.HANDLE, wt.BOOL, c_void_p,
                                           wt.DWORD, c_void_p, c_void_p]
advapi32.DuplicateTokenEx.argtypes = [wt.HANDLE, wt.DWORD, c_void_p,
                                      c_int, c_int, POINTER(wt.HANDLE)]
advapi32.LookupPrivilegeValueW.argtypes = [wt.LPWSTR, wt.LPWSTR, POINTER(_LUID)]
advapi32.AdjustTokenPrivileges.argtypes = [wt.HANDLE, wt.BOOL, c_void_p,
                                           wt.DWORD, c_void_p, c_void_p]
advapi32.DuplicateTokenEx.argtypes = [wt.HANDLE, wt.DWORD, c_void_p,
                                      c_int, c_int, POINTER(wt.HANDLE)]
advapi32.CreateProcessWithTokenW.argtypes = [wt.HANDLE, wt.DWORD, wt.LPWSTR,
                                             wt.LPWSTR, wt.DWORD, c_void_p,
                                             wt.LPWSTR, POINTER(STARTUPINFOW),
                                             POINTER(PROCESS_INFORMATION)]
advapi32.CreateProcessAsUserW.argtypes = [wt.HANDLE, wt.LPWSTR, wt.LPWSTR,
                                          c_void_p, c_void_p, wt.BOOL,
                                          wt.DWORD, c_void_p, wt.LPWSTR,
                                          POINTER(STARTUPINFOW),
                                          POINTER(PROCESS_INFORMATION)]
advapi32.CreateWellKnownSid.argtypes = [c_ulong, c_void_p, c_void_p, POINTER(wt.DWORD)]
advapi32.CheckTokenMembership.argtypes = [wt.HANDLE, c_void_p, POINTER(wt.BOOL)]
kernel32.GetEnvironmentStringsW.restype = c_void_p
kernel32.FreeEnvironmentStringsW.argtypes = [c_void_p]
ntdll.NtFilterToken.argtypes = [wt.HANDLE, c_ulong, c_void_p, c_void_p,
                                c_void_p, POINTER(wt.HANDLE)]


def _privileg_aktivieren(name):
    """Aktiviert ein Privileg des eigenen Prozesses (z. B. SeIncreaseQuotaPrivilege)."""
    token = wt.HANDLE()
    if not advapi32.OpenProcessToken(wt.HANDLE(kernel32.GetCurrentProcess()),
                                     TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, byref(token)):
        return False
    try:
        tp = _TOKEN_PRIVILEGES()
        tp.PrivilegienAnzahl = 1
        tp.Attributes = SE_PRIVILEGE_ENABLED
        if not advapi32.LookupPrivilegeValueW(None, name, byref(tp.Luid)):
            return False
        if not advapi32.AdjustTokenPrivileges(token, False, byref(tp), 0, None, None):
            return False
        return ctypes.get_last_error() != ERROR_NOT_ALL_ASSIGNED
    finally:
        kernel32.CloseHandle(token)


def _eigenes_token_oeffnen(zugriff):
    token = wt.HANDLE()
    if advapi32.OpenProcessToken(wt.HANDLE(kernel32.GetCurrentProcess()), zugriff, byref(token)):
        return token
    return None


_ADMIN_SID_PUFFER = None


def _administratoren_sid():
    """Sid der Gruppe 'Administratoren' (S-1-5-32-544) als Puffer."""
    global _ADMIN_SID_PUFFER
    if _ADMIN_SID_PUFFER is None:
        puffer = ctypes.create_string_buffer(68)
        groesse = wt.DWORD(68)
        if advapi32.CreateWellKnownSid(26, None, puffer, byref(groesse)):  # WinBuiltinAdministratorsSid
            _ADMIN_SID_PUFFER = puffer
            return puffer
        return None
    return _ADMIN_SID_PUFFER


TOKEN_IMPERSONATION_TYP = 2


def _token_ist_erhoeht(token):
    """Wahr nur wenn das Token WIRKLICH Admin-Rechte ausüben darf:
    TokenElevation gesetzt UND Mitgliedschaft bei den Administratoren
    aktiv (CheckTokenMembership ignoriert 'nur verweigern'-Gruppen,
    wie sie Trustlevel- und LUA-gefilterte Token haben)."""
    elev = wt.DWORD(0)
    zurueck = wt.DWORD(0)
    if not advapi32.GetTokenInformation(token, TOKEN_ELEVATION, byref(elev),
                                        ctypes.sizeof(elev), byref(zurueck)):
        return False
    if not elev.value:
        return False
    sid = _administratoren_sid()
    if sid is None:
        return True
    # CheckTokenMembership braucht ein Impersonations-Token
    pruef = wt.HANDLE()
    if not advapi32.DuplicateTokenEx(token, MAXIMUM_ALLOWED, None,
                                     SECURITY_IMPERSONATION, TOKEN_IMPERSONATION_TYP,
                                     byref(pruef)):
        # Kein Duplizier-Recht? Dann bleibt nur die grobe Prüfung.
        return bool(elev.value)
    try:
        mitglied = wt.BOOL(0)
        if not advapi32.CheckTokenMembership(pruef, sid, byref(mitglied)):
            return False
        return bool(mitglied)
    finally:
        kernel32.CloseHandle(pruef)


def _token_ist_nicht_erhoeht(token):
    return not _token_ist_erhoeht(token)


def _umgebungs_block():
    """Baut einen Unicode-Umgebungsblock aus der Umgebung dieses Prozesses.
    Nötig, weil gestartete Prozesse ohne expliziten Block (z. B. PowerShell)
    sonst mit Fehler 0xc0000142 sterben."""
    zeiger = kernel32.GetEnvironmentStringsW()
    if not zeiger:
        return None
    try:
        teile = []
        p = zeiger
        while True:
            eintrag = ctypes.wstring_at(p)
            if not eintrag:
                break
            teile.append(eintrag)
            p += (len(eintrag) + 1) * 2
        block = "\0".join(teile) + "\0\0"
        return ctypes.create_unicode_buffer(block)
    finally:
        kernel32.FreeEnvironmentStringsW(zeiger)


def _start_untersuchen(pi):
    """Wartet kurz und prüft, ob der neue Prozess am Leben bleibt.
    Liefert (lebt, exit_code) und schließt die Prozesse-Griffe."""
    kernel32.WaitForSingleObject(pi.hProcess, 1500)
    code = wt.DWORD(0)
    kernel32.GetExitCodeProcess(pi.hProcess, byref(code))
    kernel32.CloseHandle(pi.hThread)
    kernel32.CloseHandle(pi.hProcess)
    return (code.value == 259, code.value)  # 259 = STILL_ACTIVE


_WEG_DIREKT = ("direkt", "AsUser", 0)
_WEG_AUSBRUCH = ("mit Auftrags-Ausbruch", "AsUser", 0x00100000)  # CREATE_BREAKAWAY_FROM_JOB
_WEG_PROFIL = ("mit Benutzerprofil", "WithTokenW", 0x1)          # LOGON_WITH_PROFILE


def _versuche_start_mit_token(token, programm_pfad, befehlszeile, arbeitsordner, wege=None):
    """Startet ein Programm ohne Admin und prüft, ob es am Leben bleibt.
    Schlägt ein Weg an (Prozess stirbt sofort), wird der nächste probiert."""
    if wege is None:
        wege = [_WEG_DIREKT, _WEG_AUSBRUCH, _WEG_PROFIL]
    neu = wt.HANDLE()
    if not advapi32.DuplicateTokenEx(token, MAXIMUM_ALLOWED, None,
                                     SECURITY_IMPERSONATION, TOKEN_PRIMARY, byref(neu)):
        return (False, f"DuplicateTokenEx Fehler {ctypes.get_last_error()}")
    try:
        umgebung = _umgebungs_block()
        umgebung_zeiger = ctypes.cast(umgebung, c_void_p) if umgebung else None
        for beschreibung, art, extra_flags in wege:
            si = STARTUPINFOW()
            si.cb = ctypes.sizeof(STARTUPINFOW)
            si.dwFlags = 0x1  # STARTF_USESHOWWINDOW
            si.wShowWindow = SW_SHOWNORMAL
            si.lpDesktop = "WinSta0\\Default"
            pi = PROCESS_INFORMATION()
            zeile = ctypes.create_unicode_buffer(befehlszeile)
            if art == "AsUser":
                ok = advapi32.CreateProcessAsUserW(
                    neu, programm_pfad, zeile, None, None, False,
                    CREATE_UNICODE_ENVIRONMENT | extra_flags,
                    umgebung_zeiger, arbeitsordner, byref(si), byref(pi))
            else:
                ok = advapi32.CreateProcessWithTokenW(
                    neu, extra_flags, programm_pfad, zeile,
                    CREATE_UNICODE_ENVIRONMENT, umgebung_zeiger,
                    arbeitsordner, byref(si), byref(pi))
            if not ok:
                _log(f"Weg '{beschreibung}': Start fehlgeschlagen "
                     f"(Fehler {ctypes.get_last_error()}).")
                continue
            lebt, code = _start_untersuchen(pi)
            if lebt:
                return (True, beschreibung)
            _log(f"Weg '{beschreibung}': Prozess {pi.dwProcessId} beendete sich sofort "
                 f"(0x{code:08X}) – nächster Versuch.")
        return (False, "alle Wege fehlgeschlagen")
    finally:
        kernel32.CloseHandle(neu)


def _nicht_erhoehete_token_kandidaten():
    """Sammelt nicht erhöhte Token desselben Benutzers:
    1. UAC-Link-Token des eigenen (erhöhten) Prozesses,
    2. LUA-gefiltertes Kopie des eigenen Tokens,
    3. Token eines nicht erhöhten Explorer-Prozesses."""
    kandidaten = []
    eigenes = _eigenes_token_oeffnen(TOKEN_QUERY | TOKEN_DUPLICATE)
    if eigenes:
        try:
            # 1) UAC-Link-Token
            linked = wt.HANDLE()
            zurueck = wt.DWORD(0)
            if advapi32.GetTokenInformation(eigenes, 25, byref(linked),
                                            ctypes.sizeof(linked), byref(zurueck)) and linked:
                if _token_ist_nicht_erhoeht(linked):
                    kandidaten.append(("UAC-Link-Token", linked, False))
                else:
                    kernel32.CloseHandle(linked)
            # 2) LUA-gefilterte Kopie (hilft auch, wenn UAC ganz aus ist)
            gefiltert = wt.HANDLE()
            if ntdll.NtFilterToken(eigenes, 0x4, None, None, None,
                                   byref(gefiltert)) == 0 and gefiltert:
                if _token_ist_nicht_erhoeht(gefiltert):
                    kandidaten.append(("LUA-gefiltertes Token", gefiltert, False))
                else:
                    kernel32.CloseHandle(gefiltert)
        finally:
            kernel32.CloseHandle(eigenes)
    # 3) Explorer-Token (nur wenn der Explorer nicht erhöht läuft)
    eigene_sid = eigene_benutzer_sid()
    for pid, name, _eltern in prozesse_auflisten():
        if name.lower() != "explorer.exe":
            continue
        d = token_daten(pid)
        if not d or d[0] or d[1] != eigene_sid:
            continue
        h = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not h:
            continue
        try:
            e_token = wt.HANDLE()
            if advapi32.OpenProcessToken(h, TOKEN_DUPLICATE | TOKEN_QUERY, byref(e_token)):
                kandidaten.append(("Explorer-Token", e_token, True))
        finally:
            kernel32.CloseHandle(h)
        break
    return kandidaten


def _start_ueber_token_kandidaten(programm_pfad, argumente, arbeitsordner, wege=None):
    """Probiert alle nicht erhöhten Token-Kandidaten mit den gegebenen Wegen."""
    if not _privileg_aktivieren("SeIncreaseQuotaPrivilege"):
        fehler = ctypes.get_last_error()
        _log(f"WARNUNG: SeIncreaseQuotaPrivilege nicht aktivierbar (Fehler {fehler}).")
    befehlszeile = f'"{programm_pfad}"' + (f" {argumente}" if argumente else "")
    for quellname, token, gehoert_uns in _nicht_erhoehete_token_kandidaten():
        try:
            ok, weg = _versuche_start_mit_token(token, programm_pfad, befehlszeile,
                                                arbeitsordner, wege)
            if ok:
                return (True, f"{quellname} ({weg})")
        finally:
            kernel32.CloseHandle(token)
    return (False, "")


def _starte_mit_explorer_token(programm_pfad, argumente, arbeitsordner, wege=None):
    """Startet ein Programm OHNE Administrator-Rechte, indem ein nicht
    erhöhtes Token des Benutzers benutzt wird (Link-Token / LUA-Filter /
    Explorer). Gibt True zurück, wenn der Start dauerhaft gelang."""
    ok, _beschreibung = _start_ueber_token_kandidaten(programm_pfad, argumente,
                                                      arbeitsordner, wege)
    return ok


def _explorer_laeuft_nicht_erhoeht():
    """True, wenn ein Explorer-Prozess dieses Benutzers OHNE Admin läuft.
    Nur dann ist der COM-Umweg gefahrlos (ein erhöhter Explorer würde sonst
    wieder erhöhte Konsolen starten – Endlosschleife)."""
    eigene_sid = eigene_benutzer_sid()
    for pid, name, _eltern in prozesse_auflisten():
        if name.lower() == "explorer.exe":
            d = token_daten(pid)
            if d and not d[0] and d[1] == eigene_sid:
                return True
    return False


def starte_als_normaler_benutzer(programm_pfad, argumente="", arbeitsordner=None):
    """Startet ein Programm OHNE Administrator-Rechte:
    1. mit einem nicht erhöhten Token des Benutzers (mit Lebenszeichen-Prüfung),
    2. sonst über die laufende Shell-Instanz (COM, nur wenn der Explorer
       selbst nicht erhöht läuft).
    Gibt True zurück, wenn der Start gelang."""
    if _starte_mit_explorer_token(programm_pfad, argumente, arbeitsordner):
        return True
    if not _explorer_laeuft_nicht_erhoeht():
        _log("Start ohne Admin komplett fehlgeschlagen (COM-Umweg gesperrt, "
             "weil der Explorer selbst mit Admin läuft).")
        return False
    _log("Token-Wege fehlgeschlagen – Versuch über Shell-COM.")
    try:
        hr = ole32.CoInitialize(None)
        com_ok = hr >= 0
        try:
            clsid = GUID()
            if ole32.CLSIDFromProgID("Shell.Application", byref(clsid)) != 0:
                raise OSError("CLSIDFromProgID fehlgeschlagen")
            disp = c_void_p()
            if oleaut32.GetActiveObject(byref(clsid), None, byref(disp)) != 0:
                raise OSError("Laufende Shell-Instanz nicht gefunden")
            try:
                varianten = [_var_text(programm_pfad), _var_text(argumente or "")]
                varianten.append(_var_text(arbeitsordner) if arbeitsordner else _var_leer())
                varianten.append(_var_leer())                 # vOperation
                varianten.append(_var_zahl(SW_SHOWNORMAL))    # vShow
                _com_methode_rufen(disp, "ShellExecute", varianten)
                return True
            finally:
                try:
                    _com_vtbl(disp).Release(disp)
                except Exception:
                    pass
        finally:
            if com_ok:
                ole32.CoUninitialize()
    except Exception as fehler:
        _log(f"Start ohne Admin fehlgeschlagen: {fehler}")
    return False


# --------------------------------------------------------------------------
# Aufgabenplanung / Verwaltungshelfer
# --------------------------------------------------------------------------
HELFER_PS1 = r"""param(
    [Parameter(Mandatory = $true)][string]$Action,
    [Parameter(Mandatory = $true)][string]$ExePath
)
$ErrorActionPreference = 'Stop'
$taskName = 'AdminStopperWachter'
$dataDir = Join-Path $env:LOCALAPPDATA 'AdminStopper'
try {
    if (-not (Test-Path $dataDir)) { New-Item -ItemType Directory -Path $dataDir | Out-Null }
    if ($Action -eq 'create') {
        $user = "$env:USERDOMAIN\$env:USERNAME"
        $taskAction = New-ScheduledTaskAction -Execute $ExePath -Argument '--watch'
        $trigger = New-ScheduledTaskTrigger -AtLogOn -User $user
        $principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Highest
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
        $settings.ExecutionTimeLimit = 'PT0S'
        Register-ScheduledTask -TaskName $taskName -Action $taskAction -Trigger $trigger `
            -Principal $principal -Settings $settings -Force | Out-Null
        Start-ScheduledTask -TaskName $taskName
    }
    elseif ($Action -eq 'delete') {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
        Unregister-ScheduledTask -TaskName 'AdminStopperStart' -Confirm:$false -ErrorAction SilentlyContinue
        $pidFile = Join-Path $dataDir 'wacht_pid.txt'
        if (Test-Path $pidFile) {
            $raw = (Get-Content $pidFile -ErrorAction SilentlyContinue | Select-Object -First 1)
            if ($raw -match '^\d+$') {
                $p = Get-Process -Id ([int]$raw) -ErrorAction SilentlyContinue
                if ($p -and $p.ProcessName -like 'AdminStopper*') {
                    Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
                }
            }
        }
    }
    exit 0
}
catch {
    $_ | Out-File -FilePath (Join-Path $dataDir 'helper_fehler.txt') -Encoding UTF8
    exit 1
}
"""


class SHELLEXECUTEINFOW(Structure):
    _fields_ = [("cbSize", wt.DWORD), ("fMask", wt.ULONG), ("hwnd", wt.HWND),
                ("lpVerb", wt.LPCWSTR), ("lpFile", wt.LPCWSTR),
                ("lpParameters", wt.LPCWSTR), ("lpDirectory", wt.LPCWSTR),
                ("nShow", c_int), ("hInstApp", wt.HINSTANCE), ("lpIDList", c_void_p),
                ("lpClass", wt.LPCWSTR), ("hkeyClass", wt.HKEY), ("dwHotKey", wt.DWORD),
                ("hIconOrMonitor", wt.HANDLE), ("hProcess", wt.HANDLE)]


shell32.ShellExecuteExW.argtypes = [POINTER(SHELLEXECUTEINFOW)]
shell32.ShellExecuteExW.restype = wt.BOOL


def _als_admin_starten_und_warten(programm, argumente, timeout_sekunden=240):
    """Startet über UAC ('Als Administrator') und wartet auf das Ende."""
    sei = SHELLEXECUTEINFOW()
    sei.cbSize = ctypes.sizeof(SHELLEXECUTEINFOW)
    sei.fMask = SEE_MASK_NOCLOSEPROCESS | SEE_MASK_NOASYNC
    sei.lpVerb = "runas"
    sei.lpFile = programm
    sei.lpParameters = argumente
    sei.nShow = SW_SHOWNORMAL
    if not shell32.ShellExecuteExW(byref(sei)):
        return False
    if sei.hProcess:
        ergebnis = kernel32.WaitForSingleObject(sei.hProcess, int(timeout_sekunden * 1000))
        kernel32.CloseHandle(sei.hProcess)
        return ergebnis == 0  # WAIT_OBJECT_0
    return True


def aufgabe_existiert():
    try:
        r = subprocess.run(["schtasks", "/Query", "/TN", TASK_NAME],
                           creationflags=CREATE_NO_WINDOW,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return r.returncode == 0
    except Exception:
        return False


def wacht_pid_lesen():
    try:
        with open(PID_PFAD, "r", encoding="utf-8") as f:
            return int(f.read().strip())
    except Exception:
        return None


def wachter_laeuft():
    pid = wacht_pid_lesen()
    if not pid:
        return False
    h = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not h:
        return False
    try:
        puffer = ctypes.create_unicode_buffer(600)
        groesse = wt.DWORD(len(puffer))
        if kernel32.QueryFullProcessImageNameW(h, 0, puffer, byref(groesse)):
            return puffer.value.lower().endswith("adminstopper.exe")
        return False
    finally:
        kernel32.CloseHandle(h)


def _zaehler_laden():
    try:
        with open(ZAEHLER_PFAD, "r", encoding="utf-8") as f:
            return int(f.read().strip())
    except Exception:
        return 0


def _zaehler_speichern(wert):
    try:
        with open(ZAEHLER_PFAD, "w", encoding="utf-8") as f:
            f.write(str(wert))
    except OSError:
        pass


# --------------------------------------------------------------------------
# Wächter: Überwachung + Umleitung
# --------------------------------------------------------------------------
kernel32.AllocConsole.argtypes = []
kernel32.FreeConsole.argtypes = []
kernel32.SetConsoleTitleW.argtypes = [wt.LPWSTR]


def _starte_mit_geerbter_konsole(image, argumente, arbeitsordner):
    """Notweg, wenn der Wächter von der Aufgabenplanung gestartet wurde:
    Dort scheitert das NEU-Anlegen einer Konsole für herabgestufte Prozesse.
    Trick: Der Wächter legt selbst eine sichtbare Konsole an – die neu
    gestartete Konsole ERBT diese und läuft damit sichtbar und ohne Admin."""
    if not kernel32.AllocConsole():
        _log(f"Konsole konnte nicht angelegt werden (Fehler {ctypes.get_last_error()}).")
        return False
    kernel32.SetConsoleTitleW("Admin-Stopper – ohne Administrator neu gestartet")
    ok, beschreibung = _start_ueber_token_kandidaten(
        image, argumente, arbeitsordner, [_WEG_DIREKT, _WEG_AUSBRUCH, _WEG_PROFIL])
    kernel32.FreeConsole()
    return ok


def konsole_umleiten(pid, name, zustand):
    """Schließt eine Admin-Konsole und startet sie ohne Admin neu."""
    image, befehlszeile, ordner = lese_prozess_strings(pid)
    if befehlszeile and MARKER in befehlszeile:
        return False
    if not image:
        _log(f"PID {pid} ({name}): ProgrammPFAD nicht lesbar – übersprungen.")
        return False
    argumente = extrahiere_argumente(befehlszeile or "")
    arbeitsordner = ordner if ordner and os.path.isdir(ordner) else None

    # 1) Die Admin-Konsole schließen (nur als Admin möglich)
    h = kernel32.OpenProcess(PROCESS_TERMINATE | SYNCHRONIZE | PROCESS_QUERY_LIMITED_INFORMATION,
                             False, pid)
    if not h:
        _log(f"PID {pid} ({name}): Zugriff verweigert (Fehler {ctypes.get_last_error()}).")
        return False
    try:
        if not kernel32.TerminateProcess(h, 1):
            _log(f"PID {pid} ({name}): Konnte nicht beendet werden (Fehler {ctypes.get_last_error()}).")
            return False
        kernel32.WaitForSingleObject(h, 5000)
    finally:
        kernel32.CloseHandle(h)

    # 2) Ohne Admin neu starten – Weg A: direkt über Token. Klappt das nicht
    #    (typisch, wenn der Wächter selbst von der Aufgabenplanung gestartet
    #    wurde), Weg B: über eine geerbte, sichtbare Konsole.
    ok, beschreibung = _start_ueber_token_kandidaten(
        image, argumente, arbeitsordner, [_WEG_DIREKT, _WEG_AUSBRUCH])
    if ok:
        zustand["sitzung"] += 1
        zustand["gesamt"] += 1
        _zaehler_speichern(zustand["gesamt"])
        _log(f"{name} (PID {pid}) lief MIT Admin-Rechten -> geschlossen und "
             f"ohne Admin neu gestartet ({beschreibung}).")
        return True
    _log("Direkte Token-Wege ohne Erfolg – Versuch mit geerbter Konsole.")
    if _starte_mit_geerbter_konsole(image, argumente, arbeitsordner):
        zustand["sitzung"] += 1
        zustand["gesamt"] += 1
        _zaehler_speichern(zustand["gesamt"])
        _log(f"{name} (PID {pid}) lief MIT Admin-Rechten -> geschlossen und "
             f"ohne Admin in geerbter Konsole neu gestartet.")
        return True
    _log(f"{name} (PID {pid}) wurde geschlossen, aber der Neustart ohne Admin "
         f"ist fehlgeschlagen.")
    return False


def wache_thread(zustand, ereignisse):
    _log(f"Wächter gestartet (Version {VERSION}, Admin={ist_admin()}, "
         f"Benutzer={os.environ.get('USERNAME', '?')}).")
    while zustand["laeuft"]:
        if not zustand["pausiert"]:
            try:
                for pid, name, _eltern in prozesse_auflisten():
                    if not zustand["laeuft"] or zustand["pausiert"]:
                        break
                    if name.lower() not in WATCH_NAMES:
                        continue
                    if pid == os.getpid():
                        continue
                    daten = token_daten(pid)
                    if not daten or not daten[0] or daten[1] != zustand["sid"]:
                        continue
                    if konsole_umleiten(pid, name, zustand):
                        ereignisse.put(("umgeleitet", name, pid))
            except Exception as fehler:
                _log(f"Fehler im Überwachungszyklus: {fehler}")
        time.sleep(0.5 if zustand["pausiert"] else POLL_SEKUNDEN)
    _log("Wächter beendet.")


# --------------------------------------------------------------------------
# Infobereich (Taskleisten-Symbol)
# --------------------------------------------------------------------------
NIM_ADD, NIM_MODIFY, NIM_DELETE = 0, 1, 2
NIF_MESSAGE, NIF_ICON, NIF_TIP = 1, 2, 4
WM_APP_TRAY = 0x8000 + 1          # WM_APP + 1
WM_LBUTTON_UP = 0x0202
WM_LBUTTON_DBLCLK = 0x0203
IDI_SCHILD = 32518                # Schild-Symbol von Windows
HWND_MELDUNGEN = -3               # HWND_MESSAGE (unsichtbares Fenster)

_AUSGEBLENDET_PFAD = os.path.join(DATEN_ORDNER, "ausgeblendet_starten.txt")


class NOTIFYICONDATAW(Structure):
    _fields_ = [("cbSize", wt.DWORD), ("hWnd", wt.HWND), ("uID", wt.UINT),
                ("uFlags", wt.UINT), ("uCallbackMessage", wt.UINT),
                ("hIcon", wt.HICON), ("szTip", wt.WCHAR * 128),
                ("dwState", wt.DWORD), ("dwStateMask", wt.DWORD),
                ("szInfo", wt.WCHAR * 256), ("uVersion", wt.UINT),
                ("szInfoTitle", wt.WCHAR * 64), ("dwInfoFlags", wt.DWORD)]


_LRESULT = ctypes.c_ssize_t
_TRAY_WNDPROC = WINFUNCTYPE(_LRESULT, wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)
_TRAY_RUECKRUF = None             # globale Referenz (GC-Schutz)
_TRAY_HWND = None
_TRAY_CALLBACK = None

user32.DefWindowProcW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
user32.DefWindowProcW.restype = _LRESULT
shell32.Shell_NotifyIconW.argtypes = [wt.DWORD, POINTER(NOTIFYICONDATAW)]
user32.LoadIconW.argtypes = [wt.HINSTANCE, ctypes.c_void_p]
user32.LoadIconW.restype = wt.HICON


def _tray_fensterroutine(hwnd, meldung, wparam, lparam):
    if meldung == WM_APP_TRAY and lparam in (WM_LBUTTON_UP, WM_LBUTTON_DBLCLK):
        if _TRAY_CALLBACK:
            _TRAY_CALLBACK()
    return user32.DefWindowProcW(hwnd, meldung, wparam, lparam)


def _tray_bereitstellen(callback):
    """Legt das unsichtbare Fenster für das Taskleisten-Symbol an."""
    global _TRAY_RUECKRUF, _TRAY_HWND, _TRAY_CALLBACK
    if _TRAY_HWND:
        _TRAY_CALLBACK = callback
        return _TRAY_HWND
    klasse = WNDCLASSW()
    klasse.lpfnWndProc = _TRAY_WNDPROC(_tray_fensterroutine)
    klasse.lpszClassName = "AdminStopperTrayWnd"
    klasse.hInstance = wt.HINSTANCE(kernel32.GetModuleHandleW(None))
    _TRAY_RUECKRUF = klasse.lpfnWndProc
    if not user32.RegisterClassW(byref(klasse)) and ctypes.get_last_error() != 1410:
        return None  # 1410 = Klasse existiert bereits
    hwnd = user32.CreateWindowExW(0, klasse.lpszClassName, klasse.lpszClassName,
                                  0, 0, 0, 0, 0, wt.HWND(HWND_MELDUNGEN), None,
                                  klasse.hInstance, None)
    if not hwnd:
        return None
    _TRAY_HWND = hwnd
    _TRAY_CALLBACK = callback
    return hwnd


def tray_symbol_zeigen(tooltip):
    """Zeigt das Symbol im Infobereich (Pfeil-Menü der Taskleiste)."""
    if not _TRAY_HWND:
        return False
    nic = NOTIFYICONDATAW()
    nic.cbSize = ctypes.sizeof(NOTIFYICONDATAW)
    nic.hWnd = _TRAY_HWND
    nic.uID = 1
    nic.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP
    nic.uCallbackMessage = WM_APP_TRAY
    nic.hIcon = user32.LoadIconW(None, wt.LPCWSTR(IDI_SCHILD))
    nic.szTip = tooltip[:127]
    return bool(shell32.Shell_NotifyIconW(NIM_ADD, byref(nic)))


def tray_symbol_entfernen():
    if _TRAY_HWND:
        nic = NOTIFYICONDATAW()
        nic.cbSize = ctypes.sizeof(NOTIFYICONDATAW)
        nic.hWnd = _TRAY_HWND
        nic.uID = 1
        shell32.Shell_NotifyIconW(NIM_DELETE, byref(nic))


def _ausblenden_gespeichert():
    try:
        with open(_AUSGEBLENDET_PFAD, "r", encoding="utf-8") as f:
            return f.read().strip() == "1"
    except OSError:
        return False


def _ausblenden_speichern(wert):
    try:
        with open(_AUSGEBLENDET_PFAD, "w", encoding="utf-8") as f:
            f.write("1" if wert else "0")
    except OSError:
        pass


class WNDCLASSW(Structure):
    _fields_ = [("style", wt.UINT), ("lpfnWndProc", _TRAY_WNDPROC),
                ("cbClsExtra", ctypes.c_int), ("cbWndExtra", ctypes.c_int),
                ("hInstance", wt.HINSTANCE), ("hIcon", wt.HICON),
                ("hCursor", wt.HANDLE), ("hbrBackground", wt.HBRUSH),
                ("lpszMenuName", wt.LPCWSTR), ("lpszClassName", wt.LPCWSTR)]


user32.RegisterClassW.argtypes = [POINTER(WNDCLASSW)]
user32.CreateWindowExW.argtypes = [wt.DWORD, wt.LPCWSTR, wt.LPCWSTR, wt.DWORD,
                                   ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                   ctypes.c_int, wt.HWND, wt.HMENU,
                                   wt.HINSTANCE, wt.LPVOID]


# --------------------------------------------------------------------------
# Oberflächen
# --------------------------------------------------------------------------
def _info_fenster(text, titel="Admin-Stopper"):
    root = tk.Tk()
    root.withdraw()
    messagebox.showinfo(titel, text)
    root.destroy()


class WaechterFenster:
    def __init__(self, root, zustand, ereignisse):
        self.root = root
        self.zustand = zustand
        self.ereignisse = ereignisse
        root.title(f"{FENSTER_TITEL} (Wächter)")
        root.resizable(False, False)
        rahmen = tk.Frame(root, padx=14, pady=12)
        rahmen.pack(fill="both", expand=True)

        tk.Label(rahmen, text="Admin-Stopper ist AKTIV",
                 font=("Segoe UI", 13, "bold"), fg="#1a7f37").pack(anchor="w")
        tk.Label(rahmen, wraplength=520, justify="left", text=(
            "Überwacht cmd.exe, powershell.exe und pwsh.exe deines Benutzers. "
            "Wird eine Konsole MIT Administrator-Rechten geöffnet, schließt dieses "
            "Programm sie automatisch und öffnet dieselbe Konsole ohne Admin-Rechte neu.\n\n"
            "Dieses Fenster startet automatisch bei jeder Windows-Anmeldung. Du kannst es "
            "unten in den Infobereich (Pfeil-Symbol der Taskleiste) ausblenden – der Schutz "
            "läuft dann im Hintergrund weiter. Bitte nicht BEENDEN, wenn der Schutz aktiv bleiben soll."
        )).pack(anchor="w", pady=(4, 10))

        self.zaehler_label = tk.Label(rahmen, font=("Segoe UI", 11, "bold"))
        self.zaehler_label.pack(anchor="w")
        self.letzte_label = tk.Label(rahmen, wraplength=520, justify="left", fg="#555555")
        self.letzte_label.pack(anchor="w", pady=(0, 8))

        self.protokoll = scrolledtext.ScrolledText(rahmen, height=8, width=78,
                                                   state="disabled", font=("Consolas", 9))
        self.protokoll.pack(fill="both", expand=True)

        knopf_zeile = tk.Frame(rahmen)
        knopf_zeile.pack(fill="x", pady=(10, 0))
        self.pause_knopf = tk.Button(knopf_zeile, text="Pausieren", width=16,
                                     command=self.pause_umschalten)
        self.pause_knopf.pack(side="left")
        tk.Button(knopf_zeile, text="Wächter beenden (Schutz aus)", width=28,
                  command=self.beenden).pack(side="left", padx=(8, 0))

        knopf_zeile2 = tk.Frame(rahmen)
        knopf_zeile2.pack(fill="x", pady=(8, 0))
        tk.Button(knopf_zeile2, text="In den Infobereich ausblenden (Taskleiste ^)",
                  width=42, command=self.ins_infobereich).pack(side="left")
        self.autostart_ausgeblendet = tk.BooleanVar(value=_ausblenden_gespeichert())
        tk.Checkbutton(knopf_zeile2, text="Beim Start ausgeblendet",
                       variable=self.autostart_ausgeblendet,
                       command=lambda: _ausblenden_speichern(self.autostart_ausgeblendet.get())
                       ).pack(side="left", padx=(8, 0))

        self._zaehler_aktualisieren()
        root.protocol("WM_DELETE_WINDOW", self.beenden)
        root.after(150, self._ereignisse_ablesen)
        if self.autostart_ausgeblendet.get():
            root.after(600, self.ins_infobereich)

    def ins_infobereich(self):
        """Fenster ausblenden – nur das Symbol im Infobereich bleibt übrig."""
        if not _tray_bereitstellen(self._aus_infobereich_zurueck):
            messagebox.showinfo("Admin-Stopper", "Ausblenden hier nicht möglich.")
            return
        if not tray_symbol_zeigen(f"{FENSTER_TITEL} läuft (Klick = Fenster öffnen)"):
            messagebox.showinfo("Admin-Stopper", "Ausblenden hier nicht möglich.")
            return
        self.root.withdraw()

    def _aus_infobereich_zurueck(self):
        tray_symbol_entfernen()
        self.root.deiconify()
        self.root.lift()
        self.root.focus_force()

    def _zaehler_aktualisieren(self):
        if self.zustand["pausiert"]:
            status = "PAUSIERT – es wird gerade NICHT überwacht"
            farbe = "#b45309"
        else:
            status = f"Überwachung läuft ({', '.join(sorted(WATCH_NAMES))})"
            farbe = "#1a7f37"
        self.zaehler_label.config(text=(
            f"{status}\nAdmin-Konsolen automatisch neu gestartet: "
            f"{self.zustand['sitzung']} (diese Sitzung) / {self.zustand['gesamt']} (insgesamt)"
        ), fg=farbe)

    def _ereignisse_ablesen(self):
        try:
            while True:
                art, name, pid = self.ereignisse.get_nowait()
                text = (f"{name} (PID {pid}) war als Administrator geöffnet "
                        f"→ automatisch ohne Admin neu gestartet ({time.strftime('%H:%M:%S')}).")
                self.letzte_label.config(text=text)
                self._protokoll_anhaengen(text)
                self._zaehler_aktualisieren()
                winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
        except queue.Empty:
            pass
        self.root.after(150, self._ereignisse_ablesen)

    def _protokoll_anhaengen(self, text):
        self.protokoll.config(state="normal")
        self.protokoll.insert("end", time.strftime("[%H:%M:%S] ") + text + "\n")
        self.protokoll.see("end")
        self.protokoll.config(state="disabled")

    def pause_umschalten(self):
        self.zustand["pausiert"] = not self.zustand["pausiert"]
        self.pause_knopf.config(text="Fortsetzen" if self.zustand["pausiert"] else "Pausieren")
        self._zaehler_aktualisieren()

    def beenden(self):
        if messagebox.askokcancel(
                "Wächter beenden",
                "Der Schutz wird dadurch AUSGESCHALTET, bis du ihn über die Verwaltung "
                "(AdminStopper.exe ohne Zusatz) wieder einschaltest oder dich neu anmeldest.\n\n"
                "Wirklich beenden?"):
            tray_symbol_entfernen()
            self.zustand["laeuft"] = False
            self.root.destroy()


class VerwaltungFenster:
    def __init__(self, root):
        self.root = root
        self.aktion_laeuft = False
        root.title(f"{FENSTER_TITEL} (Verwaltung)")
        root.resizable(False, False)
        rahmen = tk.Frame(root, padx=14, pady=12)
        rahmen.pack(fill="both", expand=True)

        tk.Label(rahmen, text="Admin-Stopper",
                 font=("Segoe UI", 14, "bold")).pack(anchor="w")
        tk.Label(rahmen, wraplength=540, justify="left", text=(
            "Hält deine Konsolen frei von Administrator-Rechten: Sobald jemand eine CMD- "
            "oder PowerShell-Konsole MIT Admin-Rechten öffnet, wird sie automatisch "
            "geschlossen und ohne Admin-Rechte neu gestartet. Der Wächter selbst läuft "
            "mit Admin-Rechten (das braucht er, um Admin-Konsolen schließen zu dürfen) "
            "und startet automatisch mit Windows."
        )).pack(anchor="w", pady=(2, 10))

        self.status_rahmen = tk.LabelFrame(rahmen, text="Status", padx=8, pady=6)
        self.status_rahmen.pack(fill="x")
        self.status_autostart = tk.Label(self.status_rahmen, anchor="w")
        self.status_wachter = tk.Label(self.status_rahmen, anchor="w")
        self.status_autostart.pack(fill="x")
        self.status_wachter.pack(fill="x")

        self.knopf_rahmen = tk.Frame(rahmen)
        self.knopf_rahmen.pack(fill="x", pady=(12, 0))
        oben = tk.Frame(self.knopf_rahmen)
        oben.pack(fill="x")
        self.aktivieren_knopf = tk.Button(oben, text="Schutz aktivieren (Autostart einrichten)",
                                          width=42, command=self.aktivieren)
        self.aktivieren_knopf.pack(side="left")
        self.starten_knopf = tk.Button(oben, text="Wächter jetzt starten", width=24,
                                       command=self.jetzt_starten)
        self.starten_knopf.pack(side="left", padx=(8, 0))
        unten1 = tk.Frame(self.knopf_rahmen)
        unten1.pack(fill="x", pady=(8, 0))
        self.deaktivieren_knopf = tk.Button(unten1, text="Schutz deaktivieren (Autostart entfernen)",
                                            width=42, command=self.deaktivieren)
        self.deaktivieren_knopf.pack(side="left")
        self.test_knopf = tk.Button(unten1, text="Testen: Admin-Fenster öffnen", width=24,
                                    command=self.test_starten)
        self.test_knopf.pack(side="left", padx=(8, 0))
        unten2 = tk.Frame(self.knopf_rahmen)
        unten2.pack(fill="x", pady=(8, 0))
        tk.Button(unten2, text="Protokoll anzeigen", width=24,
                  command=self.protokoll_oeffnen).pack(side="left")
        tk.Button(unten2, text="Schließen", width=24,
                  command=root.destroy).pack(side="left", padx=(8, 0))

        tk.Label(rahmen, text=f"Version {VERSION}", fg="#888888").pack(anchor="e", pady=(10, 0))

        self.status_aktualisieren()
        self.root.after(2000, self._periodisch)

    # ---------- Status ----------
    def status_aktualisieren(self):
        aufgabe = aufgabe_existiert()
        laeuft = wachter_laeuft()
        self.status_autostart.config(
            text=("Autostart mit Windows: ✔ eingerichtet" if aufgabe
                  else "Autostart mit Windows: ✖ nicht eingerichtet"),
            fg="#1a7f37" if aufgabe else "#9a3412")
        self.status_wachter.config(
            text=("Wächter läuft gerade: ✔ ja (Schutz aktiv)" if laeuft
                  else "Wächter läuft gerade: ✖ nein (kein Schutz)"),
            fg="#1a7f37" if laeuft else "#9a3412")
        self.aktivieren_knopf.config(state="disabled" if (aufgabe or self.aktion_laeuft) else "normal")
        self.deaktivieren_knopf.config(state="normal" if (aufgabe and not self.aktion_laeuft) else "disabled")
        self.starten_knopf.config(state="normal" if (aufgabe and not laeuft and not self.aktion_laeuft) else "disabled")
        self.test_knopf.config(state="normal" if laeuft else "disabled")

    def _periodisch(self):
        if not self.aktion_laeuft:
            self.status_aktualisieren()
        self.root.after(2000, self._periodisch)

    # ---------- Aktionen ----------
    def _helfer_aktion(self, aktion, frage, fertig_text):
        if not getattr(sys, "frozen", False):
            messagebox.showwarning("Admin-Stopper", "Das geht nur mit der EXE-Datei.")
            return
        if not messagebox.askyesno("Admin-Stopper", frage):
            return
        self.aktion_laeuft = True
        self.status_aktualisieren()
        self.status_wachter.config(text="Bitte im Administrator-Fenster (UAC) mit 'Ja' bestätigen …",
                                   fg="#555555")

        def arbeit():
            try:
                os.makedirs(DATEN_ORDNER, exist_ok=True)
                with open(HELFER_PFAD, "w", encoding="utf-8-sig") as f:
                    f.write(HELFER_PS1)
                powershell = os.path.join(os.environ["WINDIR"], "System32",
                                          "WindowsPowerShell", "v1.0", "powershell.exe")
                argumente = (f'-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden '
                             f'-File "{HELFER_PFAD}" -Action {aktion} -ExePath "{sys.executable}"')
                ok = _als_admin_starten_und_warten(powershell, argumente, 240)
                self.root.after(0, lambda: self._aktion_fertig(aktion, ok, fertig_text))
            except Exception as fehler:
                self.root.after(0, lambda: self._aktion_fertig(aktion, False, str(fehler)))

        threading.Thread(target=arbeit, daemon=True).start()

    def _aktion_fertig(self, aktion, ok, fertig_text):
        self.aktion_laeuft = False
        if not ok:
            messagebox.showwarning(
                "Admin-Stopper",
                "Der Administrator-Vorgang wurde nicht abgeschlossen "
                "(im UAC-Fenster 'Nein' gewählt oder Fehler).\n\n"
                "Falls ein Fehler auftrat, steht mehr in:\n" + HELFER_PFAD.replace("helper_NOADMIN_SKIP.ps1", "helper_fehler.txt"))
        elif aktion == "create" and not aufgabe_existiert():
            messagebox.showwarning("Admin-Stopper",
                                   "Der Vorgang lief, aber der Autostart-Eintrag fehlt. "
                                   "Bitte noch einmal versuchen.")
        elif aktion == "delete" and aufgabe_existiert():
            messagebox.showwarning("Admin-Stopper",
                                   "Der Vorgang lief, aber der Autostart-Eintrag ist noch da. "
                                   "Bitte noch einmal versuchen.")
        else:
            messagebox.showinfo("Admin-Stopper", fertig_text)
        self.status_aktualisieren()

    def aktivieren(self):
        self._helfer_aktion(
            "create",
            "Jetzt wird eingerichtet:\n\n"
            "  • Der Admin-Stopper startet künftig automatisch bei jeder Windows-Anmeldung\n"
            "    (mit Administrator-Rechten, damit er Admin-Konsolen schließen darf).\n"
            "  • Es erscheint EINMAL ein Administrator-Fenster (UAC) – bitte mit 'Ja' bestätigen.\n\n"
            "Einrichten und sofort starten?",
            "Fertig! Der Schutz ist aktiv und startet ab jetzt automatisch mit Windows.\n\n"
            "Das Fenster 'Admin-Stopper (Wächter)' ist der Schutz – bitte laufen lassen.")

    def deaktivieren(self):
        self._helfer_aktion(
            "delete",
            "Soll der Schutz wirklich komplett deaktiviert werden?\n\n"
            "Der Autostart-Eintrag wird entfernt und der laufende Wächter gestoppt.\n"
            "Es erscheint EINMAL ein Administrator-Fenster (UAC) – bitte mit 'Ja' bestätigen.",
            "Fertig! Der Schutz ist deaktiviert und startet nicht mehr automatisch.")

    def jetzt_starten(self):
        try:
            r = subprocess.run(["schtasks", "/Run", "/TN", TASK_NAME],
                               creationflags=CREATE_NO_WINDOW,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if r.returncode == 0:
                messagebox.showinfo("Admin-Stopper",
                                    "Der Wächter wurde gestartet (Fenster 'Admin-Stopper (Wächter)').")
            else:
                messagebox.showwarning("Admin-Stopper",
                                       "Der Start über die Aufgabenplanung hat nicht geklappt.\n"
                                       "Abhilfe: einmal ab- und wieder anmelden, oder Schutz "
                                       "über 'Aktivieren' neu einrichten.")
        except Exception as fehler:
            messagebox.showerror("Admin-Stopper", str(fehler))
        self.status_aktualisieren()

    def test_starten(self):
        if not wachter_laeuft():
            messagebox.showinfo("Admin-Stopper", "Der Wächter läuft gerade nicht – bitte erst 'Aktivieren'.")
            return
        if not messagebox.askyesno(
                "Test",
                "Es öffnet sich jetzt EINMAL ein echtes CMD-Fenster MIT Administrator-Rechten "
                "(UAC mit 'Ja' bestätigen).\n\n"
                "Erwartung: Es verschwindet innerhalb von ~2 Sekunden von selbst, und ein "
                "NEUES Fenster ohne Admin-Rechte erscheint. Darin muss 'net session' "
                "'Zugriff verweigert' melden.\n\nTest starten?"):
            return
        ergebnis = shell32.ShellExecuteW(None, "runas", "cmd.exe",
                                         "/k title Admin-Test && net session", None, SW_SHOWNORMAL)
        if ergebnis <= 32:
            messagebox.showwarning("Admin-Stopper",
                                   "Das Admin-Testfenster konnte nicht gestartet werden (UAC abgebrochen?).")

    def protokoll_oeffnen(self):
        os.makedirs(DATEN_ORDNER, exist_ok=True)
        if not os.path.exists(LOG_PFAD):
            open(LOG_PFAD, "a", encoding="utf-8").close()
        os.startfile(LOG_PFAD)


# --------------------------------------------------------------------------
# Modi
# --------------------------------------------------------------------------
def starte_waechter():
    if not ist_admin():
        _info_fenster(
            "Der Wächter braucht Administrator-Rechte (er muss Admin-Konsolen schließen dürfen).\n\n"
            "Starte ihn über die Verwaltung (AdminStopper.exe doppelklicken) und klicke auf "
            "'Schutz aktivieren' – danach startet er automatisch mit Windows.",
            "Admin-Stopper")
        return
    mutex = kernel32.CreateMutexW(None, False, MUTEX_NAME)
    if ctypes.get_last_error() == ERROR_ALREADY_EXISTS:
        _info_fenster("Der Wächter läuft bereits.", "Admin-Stopper")
        return
    os.makedirs(DATEN_ORDNER, exist_ok=True)
    zustand = {
        "laeuft": True,
        "pausiert": False,
        "sid": eigene_benutzer_sid(),
        "sitzung": 0,
        "gesamt": _zaehler_laden(),
    }
    with open(PID_PFAD, "w", encoding="utf-8") as f:
        f.write(str(os.getpid()))
    ereignisse = queue.Queue()
    thread = threading.Thread(target=wache_thread, args=(zustand, ereignisse), daemon=True)
    thread.start()
    try:
        root = tk.Tk()
        WaechterFenster(root, zustand, ereignisse)
        root.mainloop()
    finally:
        zustand["laeuft"] = False
        try:
            os.remove(PID_PFAD)
        except OSError:
            pass


def starte_manager():
    root = tk.Tk()
    VerwaltungFenster(root)
    root.mainloop()


def autotest():
    """Interner Selbsttest: schreibt Ergebnisse nach autotest.json."""
    ergebnis = {}
    ergebnis["version"] = VERSION
    ergebnis["admin_selbst"] = ist_admin()
    ergebnis["eigene_sid"] = eigene_benutzer_sid()
    ergebnis["frozen"] = bool(getattr(sys, "frozen", False))

    # 1) Befehlszeilen-Lesezugriff (PEB) bei einem Kindprozess
    kind = subprocess.Popen(["cmd.exe", "/c", "ping -n 6 127.0.0.1 > nul"],
                            creationflags=CREATE_NO_WINDOW)
    time.sleep(0.8)
    image, befehlszeile, ordner = lese_prozess_strings(kind.pid)
    ergebnis["peb_image_ok"] = bool(image and image.lower().endswith("cmd.exe"))
    ergebnis["peb_cmdline_ok"] = bool(befehlszeile and "ping" in befehlszeile)
    kind.kill()
    kind.wait()

    # 2) Eigenen Prozess lesen
    _img, eigene_zeile, _ord = lese_prozess_strings(os.getpid())
    ergebnis["peb_selbst_ok"] = bool(eigene_zeile and "autotest" in eigene_zeile)

    # 3) Start ohne Admin (öffnet kurz einen Editor zum Nachweis)
    vorher = {p for p, n, _e in prozesse_auflisten() if n.lower() == "notepad.exe"}
    editor = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "System32", "notepad.exe")
    try:
        ergebnis["start_ohne_admin_ok"] = starte_als_normaler_benutzer(editor, "", None)
    except Exception as fehler:
        ergebnis["start_ohne_admin_ok"] = False
        ergebnis["start_fehler"] = str(fehler)
    time.sleep(1.5)
    nachher = {p for p, n, _e in prozesse_auflisten() if n.lower() == "notepad.exe"}
    neue = nachher - vorher
    ergebnis["prozess_gestartet"] = bool(neue)
    if neue:
        ergebnis["neuer_prozess_ohne_admin"] = not token_daten(next(iter(neue)))[0]
    for pid in neue:
        subprocess.run(["taskkill", "/PID", str(pid), "/F"],
                       creationflags=CREATE_NO_WINDOW, stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL)

    # 4) Aufgabenplanung: nur Info, ob der Eintrag schon existiert
    ergebnis["aufgabe_existiert_bereits"] = aufgabe_existiert()
    ergebnis["gesamter_zaehler"] = _zaehler_laden()

    os.makedirs(DATEN_ORDNER, exist_ok=True)
    with open(AUTOTEST_PFAD, "w", encoding="utf-8") as f:
        json.dump(ergebnis, f, ensure_ascii=False, indent=2)


def main():
    os.makedirs(DATEN_ORDNER, exist_ok=True)
    argumente = sys.argv[1:]
    if "--autotest" in argumente:
        autotest()
    elif "--watch" in argumente:
        starte_waechter()
    else:
        starte_manager()


if __name__ == "__main__":
    main()
